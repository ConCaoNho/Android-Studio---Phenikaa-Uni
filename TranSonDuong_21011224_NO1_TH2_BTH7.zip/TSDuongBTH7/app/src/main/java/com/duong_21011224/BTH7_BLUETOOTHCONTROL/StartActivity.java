package com.duong_21011224.BTH7_BLUETOOTHCONTROL;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Toast;

public class StartActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);
        boolean start = StartPermission.requestBluetoothPermission(this);
        if (start){
            new AlertDialog.Builder(StartActivity.this)
                    .setTitle("Request Bluetooth Permission")
                    .setMessage("Checked Permission")
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Intent mainIntent = new Intent(StartActivity.this, MainActivity.class);
                            startActivity(mainIntent);
                            finish();
                        }
                    })
                    .setNegativeButton("No", null)
                    .show();
        }
        else {
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    Intent mainIntent = new Intent(StartActivity.this, MainActivity.class);
                    startActivity(mainIntent);
                    finish();
                }
            },1000);
        }
        Toast.makeText(getApplicationContext(),"Started", Toast.LENGTH_SHORT).show();
    }
}