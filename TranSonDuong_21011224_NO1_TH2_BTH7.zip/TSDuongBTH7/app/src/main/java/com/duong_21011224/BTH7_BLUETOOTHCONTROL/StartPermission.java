package com.duong_21011224.BTH7_BLUETOOTHCONTROL;
import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.PackageManagerCompat;

public class StartPermission {
    public static boolean requestBluetoothPermission(Activity activity) {
        boolean needPermission = false;
        if (Build.VERSION.SDK_INT >= 32) {
            if (ContextCompat.checkSelfPermission(activity, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_DENIED) {
                needPermission = true;
            }
            if (ContextCompat.checkSelfPermission(activity, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_DENIED) {
                needPermission = true;
            }
            if (ContextCompat.checkSelfPermission(activity, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_DENIED) {
                needPermission = true;
            }
            if (needPermission) {
                ActivityCompat.requestPermissions(activity, new String[]{
                        Manifest.permission.BLUETOOTH_CONNECT,
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.BLUETOOTH_SCAN,
                },100);
            }
        }
        return needPermission;
    }
}

