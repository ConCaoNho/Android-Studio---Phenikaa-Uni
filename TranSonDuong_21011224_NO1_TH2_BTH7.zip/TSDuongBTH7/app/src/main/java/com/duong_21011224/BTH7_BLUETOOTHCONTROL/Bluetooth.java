package com.duong_21011224.BTH7_BLUETOOTHCONTROL;

import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.os.Bundle;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.LinkedList;
import java.util.UUID;

public class Bluetooth extends AppCompatActivity {
    private Button btBack, btAuto, btSend;
    EditText edSend;
    TextView tvReceive;
    boolean autoSend = false;
    BluetoothAdapter bluetoothAdapter;
    BluetoothSocket bluetoothSocket;
    BluetoothManager bluetoothManager;
    private BluetoothDevice esp32Device;
    private ConnectedThread connectedThread;
    private Handler handler= new Handler();
    private Runnable autoSendRunnable;
    private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    String deviceAddress;
    private LinkedList<String> receivedDataList = new LinkedList<>();
    @SuppressLint("MissingPermission")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bluetooth);
        StartPermission.requestBluetoothPermission(this);
        btBack = findViewById(R.id.btBack);
        btAuto = findViewById(R.id.btAuto);
        btSend = findViewById(R.id.btSend);
        edSend = findViewById(R.id.edSend);
        tvReceive= findViewById(R.id.tvReceive);
        bluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        if( Build.VERSION.SDK_INT >= 31) bluetoothAdapter= bluetoothManager.getAdapter();
        else bluetoothAdapter= bluetoothAdapter.getDefaultAdapter();
        //Lay dia chi Bluetooth tu Intent
        deviceAddress = getIntent().getStringExtra("Device_Address");
        esp32Device = bluetoothAdapter.getRemoteDevice(deviceAddress);
        try {
            bluetoothSocket = esp32Device.createInsecureRfcommSocketToServiceRecord(MY_UUID);
            bluetoothSocket.connect();
            connectedThread = new ConnectedThread(bluetoothSocket);
            connectedThread.start();
        } catch (IOException e){
            e.printStackTrace();
            Toast.makeText(this,"Failed to connect to Bluetooth device", Toast.LENGTH_SHORT).show();
            finish();
        }
        btBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        btSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                handler.removeCallbacks(autoSendRunnable);
                autoSend = false;
                String dataToSend = edSend.getText().toString();
                if (!dataToSend.isEmpty()) {
                    connectedThread.write(dataToSend + "\n");
                } else {
                    Toast.makeText(Bluetooth.this, "Please enter data to send", Toast.LENGTH_SHORT).show();
                }
            }
        });

        int timeDelay = 100;

        autoSendRunnable = new Runnable() {
            @Override
            public void run() {
                if (autoSend) {
                    String dataToSend = edSend.getText().toString();
                    if (!dataToSend.isEmpty()) {
                        connectedThread.write(dataToSend + "\n");
                    } else {
                        Toast.makeText(Bluetooth.this, "Please enter data to send", Toast.LENGTH_SHORT).show();
                    }
                    // Lặp lại gửi sau timeDelay ms
                    handler.postDelayed(this, timeDelay);
                }
            }
        };

        btAuto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                autoSend = !autoSend;
                if (autoSend) {
                    btAuto.setText("Stop Auto");
                    handler.postDelayed(autoSendRunnable, timeDelay);
                } else {
                    btAuto.setText("Start Auto");
                    handler.removeCallbacks(autoSendRunnable);
                }
            }
        });

    }
    @Override
    protected void onDestroy(){
        super.onDestroy();
        if(bluetoothSocket != null){
            try {
                bluetoothSocket.close();
            } catch (IOException e){
                e.printStackTrace();
            }
        }
    }
    private class ConnectedThread extends Thread{
        private final InputStream inputStream;
        private final OutputStream outputStream;
        ConnectedThread(BluetoothSocket socket){
            InputStream tempIn= null;
            OutputStream tempOut = null;
            try {
                tempIn = socket.getInputStream();
                tempOut = socket.getOutputStream();

            } catch (IOException e){
                e.printStackTrace();
            }
            inputStream = tempIn;
            outputStream = tempOut;
        }
        private void addReceivedDataToList(String data){
            // Kiem tra xem danh sach co qua 10 phan tu khong
            if (receivedDataList.size() >=10){
                receivedDataList.remove(0);
            }
            // Them dong du lieu moi vao danh sach
            receivedDataList.add(data);
        }
        void write(String data){
            byte[] msgBuffer = data.getBytes();
            try {
                outputStream.write(msgBuffer);
            } catch (IOException e){
                e.printStackTrace();
            }
        }
        private void handleReceivedData(String receivedData){
            addReceivedDataToList(receivedData);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    //Hien thi du lieu tu danh sach len TextView
                    StringBuilder displayText = new StringBuilder();
                    for (String data: receivedDataList){
                        displayText.append(data).append("\n");
                    }
                    tvReceive.setText(displayText.toString());
                }
            });
        }
        public void run() {
            try {
                InputStreamReader reader = new InputStreamReader(inputStream, StandardCharsets.UTF_8);
                StringBuilder receivedDataBuilder = new StringBuilder();
                char[] buffer = new char[1024];
                int bytesRead;

                while (true) {
                    bytesRead = reader.read(buffer);

                    if (bytesRead == -1) {
                        // Kết thúc dữ liệu, thoát khỏi vòng lặp
                        break;
                    }

                    // Nối dữ liệu mới đọc vào chuỗi tổng
                    receivedDataBuilder.append(buffer, 0, bytesRead);

                    // Chuyển toàn bộ dữ liệu đã nhận thành chuỗi
                    String receivedData = receivedDataBuilder.toString();

                    // Tìm ký tự kết thúc ($ hoặc xuống dòng)
                    int newlineIndex = receivedData.indexOf('$');
                    if (newlineIndex == -1) newlineIndex = receivedData.indexOf('\r');
                    if (newlineIndex == -1) newlineIndex = receivedData.indexOf('\n');

                    if (newlineIndex != -1) {
                        // Lấy chuỗi từ đầu đến ký tự kết thúc
                        String completeData = receivedData.substring(0, newlineIndex);
                        handleReceivedData(completeData);

                        // Xoá phần đã xử lý khỏi StringBuilder
                        receivedDataBuilder.delete(0, newlineIndex + 1);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}