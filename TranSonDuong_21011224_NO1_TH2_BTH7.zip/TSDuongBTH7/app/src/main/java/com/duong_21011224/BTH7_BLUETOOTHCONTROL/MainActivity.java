package com.duong_21011224.BTH7_BLUETOOTHCONTROL;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.PackageManagerCompat;
import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.lang.reflect.AnnotatedElement;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.LinkedList;
import java.util.UUID;


public class MainActivity extends AppCompatActivity {
    ListView listview, scanListview;
    Button buttonOn, buttonOff, buttonScan;
    Intent intOnBLE;
    ActivityResultLauncher<Intent> EnableBLE;
    ArrayList<String> stringArrayList = new ArrayList<>();
    ArrayAdapter<String> arrayAdapter;
    BluetoothAdapter bluetoothAdapter;
    BluetoothManager bluetoothManager;
    // TẠO 2 ARRAYLIST RIÊNG BIỆT
    ArrayList<String> pairedDevicesList = new ArrayList<>();    // Cho thiết bị đã ghép nối
    ArrayList<String> scannedDevicesList = new ArrayList<>();   // Cho thiết bị quét được

    ArrayAdapter<String> pairedAdapter;
    ArrayAdapter<String> scannedAdapter;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buttonOn = findViewById(R.id.buttonOn);
        buttonOff = findViewById(R.id.buttonOff);
        buttonScan = findViewById(R.id.buttonScan);
        bluetoothManager= (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        listview = findViewById(R.id.listview);
        scanListview= findViewById(R.id.scanListview);
        IntentFilter intentFilter= new IntentFilter(BluetoothDevice.ACTION_FOUND);
        registerReceiver(broadcastReceiver, intentFilter);

        boolean start= StartPermission.requestBluetoothPermission(this);
        if (start){
            Toast.makeText(getApplicationContext(),"Hay khoi dong lai", Toast.LENGTH_LONG).show();
            return;
        }
        if(Build.VERSION.SDK_INT >=31) bluetoothAdapter= bluetoothManager.getAdapter();
        else bluetoothAdapter= bluetoothAdapter.getDefaultAdapter();
        intOnBLE = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
        EnableBLE= registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        int resultcode = result.getResultCode();
                        if (resultcode == RESULT_OK) {
                            Toast.makeText(getApplicationContext(), "Bluetooth  Started", Toast.LENGTH_SHORT).show();
                        }
                        else{
                            Toast.makeText(getApplicationContext(),"Bluetooth cannot start",Toast.LENGTH_LONG).show();
                        }
                    }
                }
        );
        buttonOn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (bluetoothAdapter== null){
                    Toast.makeText(getApplicationContext(),"Bluetooth not...",Toast.LENGTH_LONG).show();
                }
                else {
                    if (!bluetoothAdapter.isEnabled()){
                        Toast.makeText(getApplicationContext(),"Bluetooth Off",Toast.LENGTH_LONG).show();
                        EnableBLE.launch(intOnBLE);
                    }
                    else {
                        Toast.makeText(getApplicationContext(),"Bluetooth Started",Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        buttonOff.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("MissingPermission")
            @Override
            public void onClick(View v) {
                if (!bluetoothAdapter.isEnabled()) {
                    Toast.makeText(getApplicationContext(), "Bluetooth đã tắt", Toast.LENGTH_SHORT).show();
                } else {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        // Android 13 (API 33) trở lên: không thể tắt Bluetooth bằng code
                        Toast.makeText(getApplicationContext(), "Không thể tắt Bluetooth từ ứng dụng.\nVui lòng tắt thủ công.", Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS);
                        startActivity(intent); // Mở giao diện Bluetooth để người dùng tắt
                    } else {
                        // Android < 13: vẫn tắt được bằng code
                        bluetoothAdapter.disable();
                        Toast.makeText(getApplicationContext(), "Đang tắt Bluetooth...", Toast.LENGTH_SHORT).show();
                    }
                    // Xóa dữ liệu danh sách scan và cập nhật ListView
                    stringArrayList.clear();
                    if (arrayAdapter != null) arrayAdapter.notifyDataSetChanged();
                    // Ẩn cả 2 ListView bằng cách gán adapter null
                    listview.setAdapter(null);
                    scanListview.setAdapter(null);
                }
            }
        });
        buttonScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.BLUETOOTH_SCAN}, 100);
                        return;
                    }
                } else {
                    if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 100);
                        return;
                    }
                }

                if (ContextCompat.checkSelfPermission(MainActivity.this,Manifest.permission.ACCESS_FINE_LOCATION)== PackageManager.PERMISSION_DENIED) {
                    ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION},100);
                    return;
                }

                // Bắt đầu quét
                bluetoothAdapter.startDiscovery();

                // Chỉ xóa scanListview và reset dữ liệu scan
                scanListview.setAdapter(null);
                stringArrayList.clear();

                // GỌI LẠI showBLEconnect() để hiển thị thiết bị đã ghép nối
                showBLEconnect();
            }
        });

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                ArrayAdapter<String> adapter = (ArrayAdapter<String>) listview.getAdapter();
                String selectedItem = adapter.getItem(position);
                String[] parts = selectedItem.split("\n");

                if (parts.length >= 2) {
                    String deviceName = parts[0];
                    String deviceAddress = parts[1];

                    // KIỂM TRA XEM CÓ PHẢI ESP32 KHÔNG
                    if (deviceName != null && (deviceName.toLowerCase().contains("esp32") ||
                            deviceName.toLowerCase().contains("esp"))) {
                        // Chỉ kết nối với ESP32
                        Intent intent = new Intent(MainActivity.this, Bluetooth.class);
                        intent.putExtra("Device_Address", deviceAddress);
                        startActivity(intent);
                        Toast.makeText(getApplicationContext(),
                                "Đang kết nối với " + deviceName, Toast.LENGTH_SHORT).show();
                    } else {
                        // Thiết bị khác chỉ hiển thị thông tin
                        Toast.makeText(getApplicationContext(),
                                "Thông tin thiết bị:\n" + deviceName + "\n" + deviceAddress +
                                        "\n(Chỉ ESP32 mới có thể gửi/nhận dữ liệu)",
                                Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Không thể lấy địa chỉ thiết bị", Toast.LENGTH_SHORT).show();
                }
            }
        });

        listview.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            private static final long LONG_PRESS_DURATION = 1500; // Thoi gian giu lau
            private Handler handler= new Handler();
            private boolean isLongPress= false;
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long l) {
                isLongPress = true;
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (isLongPress){
                            ArrayAdapter<String> adapter= (ArrayAdapter<String>) listview.getAdapter();
                            List<String> listItems = new ArrayList<>();
                            for (int i =0; i <adapter.getCount();i++){
                                listItems.add(adapter.getItem(i));
                            }
                            String selectedItem = listItems.get(position);
                            String[] parts = selectedItem.split("\n");
                            if (parts.length >= 2){
                                String deviceName = parts[0];
                                String deviceAddress = parts[1];
                                BluetoothDevice selectedDevice = bluetoothAdapter.getRemoteDevice(deviceAddress);
                                new AlertDialog.Builder(MainActivity.this)
                                        .setTitle("Confirm")
                                        .setMessage(deviceName + "unpair?")
                                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialogInterface, int i) {
                                                unpairDevice(selectedDevice);
                                                Toast.makeText(getApplicationContext(),deviceName +"\n"+ deviceAddress + "unpaired", Toast.LENGTH_SHORT).show();
                                            }
                                        }).setNegativeButton("No",null).show();
                            }
                            isLongPress = false; // dat lai trang thai long press
                        }
                    }
                },LONG_PRESS_DURATION);
                return true;  // tro ve true để ngăn sự kiện click ngắn xảy ra khi long press
            }
        });
        scanListview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @SuppressLint("MissingPermission")
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                // LẤY TỪ scannedDevicesList
                String selectedItem = scannedDevicesList.get(position);
                String[] parts = selectedItem.split("\n");

                if (parts.length >= 2) {
                    String deviceName = parts[0];
                    String deviceAddress = parts[1];
                    BluetoothDevice selectedDevice = null;

                    @SuppressLint("MissingPermission") Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();
                    boolean foundInPairedDevices = false;

                    for (BluetoothDevice device : pairedDevices) {
                        if (device.getName().equals(deviceName) && device.getAddress().equals(deviceAddress)) {
                            foundInPairedDevices = true;
                            break;
                        }
                    }

                    if (!foundInPairedDevices) {
                        try {
                            selectedDevice = bluetoothAdapter.getRemoteDevice(deviceAddress);
                            if (selectedDevice != null) {
                                BluetoothDevice finalSelectedDevice = selectedDevice;
                                new AlertDialog.Builder(MainActivity.this)
                                        .setTitle("Confirm")
                                        .setMessage(deviceName + "can be pair???")
                                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialogInterface, int i) {
                                                @SuppressLint("MissingPermission") boolean paired = finalSelectedDevice.createBond();
                                                if(!paired) {
                                                    Toast.makeText(getApplicationContext(),deviceName +"\n" + deviceAddress + "unpaired",Toast.LENGTH_SHORT).show();
                                                }
                                            }
                                        }).setNegativeButton("No", null).show();
                            } else {
                                Toast.makeText(getApplicationContext(), "Không tìm thấy thiết bị có tên " + deviceName, Toast.LENGTH_SHORT).show();
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            Toast.makeText(getApplicationContext(), "Lỗi khi thực hiện pair với thiết bị " + deviceName, Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Thiết bị " + deviceName + " đã được pair trước đó", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        Handler autoRefreshHandler= new Handler();
        Runnable autoRefreshRunnable = new Runnable() {
            @Override
            public void run() {
                showBLEconnect();
                // Len lich de tu dong lam moi lai sau khoang thoi gian
                autoRefreshHandler.postDelayed(this,1000);

            }
        };
        autoRefreshHandler.postDelayed(autoRefreshRunnable,1000);
    }
    @SuppressLint("MissingPermission")
    private void showBLEconnect(){
        Set<BluetoothDevice> bt = bluetoothAdapter.getBondedDevices();
        pairedDevicesList.clear(); // XÓA DANH SÁCH THIẾT BỊ ĐÃ GHÉP NỐI

        if (bt.size() > 0){
            for (BluetoothDevice device : bt) {
                String item = device.getName() + "\n" + device.getAddress();
                pairedDevicesList.add(item);
            }
            pairedAdapter = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1, pairedDevicesList);
            listview.setAdapter(pairedAdapter);
        } else {
            Toast.makeText(this, "Không có thiết bị đã kết nối", Toast.LENGTH_SHORT).show();
            listview.setAdapter(null);
        }
    }

    BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);

                if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_DENIED) {
                    ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.BLUETOOTH_SCAN}, 100);
                }

                // THÊM VÀO DANH SÁCH QUÉT
                String deviceInfo = device.getName() + "\n" + device.getAddress();
                if (!scannedDevicesList.contains(deviceInfo)) {
                    scannedDevicesList.add(deviceInfo);
                }

                // Loại bỏ thiết bị đã pair khỏi danh sách quét
                if (pairedAdapter != null) {
                    for (int i = 0; i < pairedDevicesList.size(); i++) {
                        if (pairedDevicesList.get(i).equals(deviceInfo)) {
                            scannedDevicesList.remove(deviceInfo);
                            Toast.makeText(getApplicationContext(), "Loại bỏ " + device.getName() + " (đã ghép nối)", Toast.LENGTH_SHORT).show();
                            break;
                        }
                    }
                }

                scannedAdapter = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1, scannedDevicesList);
                scanListview.setAdapter(scannedAdapter);
            }
        }
    };
    private void unpairDevice(BluetoothDevice device){
        try {
            Method method = device.getClass().getMethod("removeBond",(Class[]) null);
            method.invoke(device,(Object[]) null);
        } catch (Exception e){
            e.printStackTrace();
        }
    }
    @Override
    protected void onDestroy(){
        super.onDestroy();
        unregisterReceiver(broadcastReceiver);
    }
}