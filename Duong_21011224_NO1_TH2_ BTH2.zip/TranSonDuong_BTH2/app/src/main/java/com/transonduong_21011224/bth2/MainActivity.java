package com.transonduong_21011224.bth2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {
    ArrayList<String> titleslist = new ArrayList<>();
    ArrayList<String> noteList = new ArrayList<>();
    ArrayList<String> timelist = new ArrayList<>();
    private ArrayAdapter<String> adapter;
    private String mode = "";
    private static final String PREFS_NAME = "MyPrefs";
    private static final String TITLES_KEY = "titles";
    private static final String NOTES_KEY = "notes";
    private static final String TIMES_KEY = "times";  // Chèn thêm thời gian

    private ListView lvNote;
    private FloatingActionButton btAdd;
    private ArrayList<String> noteTitles;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView lvNote = findViewById(R.id.lvNote);
        FloatingActionButton btAdd = findViewById(R.id.btNote);
        loadNotesFromSharedPreference();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,titleslist);
        lvNote.setAdapter(adapter);
        lvNote.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(MainActivity.this, NoteTaking.class);
                intent.putExtra("title", titleslist.get(position));
                intent.putExtra("note", noteList.get(position));
                intent.putExtra("position", position);
                intent.putExtra("mode", "edit");
                startActivity(intent);
                finish(); // Có thể để hoặc bỏ tùy ý
            }
        });
        btAdd.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                //saveNotesToSharedPreferences();
                Intent intent=new Intent(MainActivity.this,NoteTaking.class);
                intent.putExtra("mode","add");
                startActivity(intent);
                finish();
            }
        });
        lvNote.setOnItemLongClickListener((parent, view, position, id)->{
            try {
                AlertDialog.Builder builder =new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Notification");
                builder.setMessage("Are you sure the delete note?");
                builder.setPositiveButton("Yes",(dialog,which) ->{
                    removeItem(position);
                    Toast.makeText(getApplicationContext(),"deleted note from note list",Toast.LENGTH_SHORT).show();
                    saveNotesToSharedPreferences();
                });
                builder.setNegativeButton("No",(dialog,which) ->{

                });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
            }
            catch (Exception e){}
            return true;
        });
    }

    private void loadNotesFromSharedPreference() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String savedTitles = prefs.getString(TITLES_KEY, "");
        String savedNotes = prefs.getString(NOTES_KEY, "");
        String savedTimes = prefs.getString(TIMES_KEY, "");  // thêm thời gian
        if (!savedTitles.isEmpty() && !savedNotes.isEmpty()){
            titleslist.addAll(Arrays.asList(savedTitles.split(",")));
            noteList.addAll(Arrays.asList(savedNotes.split(",")));
        }
        if (!savedTimes.isEmpty()) {
            timelist.addAll(Arrays.asList(savedTimes.split(","))); // Thêm thời gian
        }
    }
    private void saveNotesToSharedPreferences(){
        SharedPreferences.Editor editor=getSharedPreferences(PREFS_NAME,MODE_PRIVATE).edit();
        editor.putString(TITLES_KEY,String.join(",",titleslist));
        editor.putString(NOTES_KEY,String.join(",",noteList));
        editor.putString(TIMES_KEY, String.join(",", timelist));  // thêm thời gian
        editor.apply();
    }
    private void removeItem(int position){
        //Remove the item from your data source
        if (position >= 0 && position <titleslist.size()){
            titleslist.remove(position);
            noteList.remove(position);
            adapter.notifyDataSetChanged();
            if (position < timelist.size()) timelist.remove(position);  // thêm time
            saveNotesToSharedPreferences();
        }
    }


}
