package com.transonduong_21011224.bth2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.content.Intent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.ArrayList;
import java.util.Arrays;

public class NoteTaking extends AppCompatActivity {
    private static final String PREFS_NAME = "MyPrefs";
    private static  final String TITLES_NAME="titles";
    private static final String NOTES_KEY="notes";

    ArrayList<String> titlesList = new ArrayList<>();
    ArrayList<String> noteslist = new ArrayList<>();
    EditText titleText;
    EditText notesText;
    private Button btAdd;
    private String mode;
    private int notePosition;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_taking);

        notesText = findViewById(R.id.edNContents);
        titleText = findViewById(R.id.edNTilte);
        btAdd = findViewById(R.id.btAddNote);
        loadNotesFromSharedPreferences();
        //Nhận dữ liệu từ Intent
        Intent intent =getIntent();
        mode =intent.getStringExtra("mode");
        if (mode.equals("edit")){
            String _title= intent.getStringExtra("title");
            String _note= intent.getStringExtra("note");
            notePosition = intent.getIntExtra("position",-1);
            titleText.setText((_title));
            notesText.setText(_note);
        }
        btAdd.setOnClickListener(view ->{
            String newtitle = titleText.getText().toString();
            String newnotes = notesText.getText().toString();
            if (mode.equals("add")){
                if (!newnotes.isEmpty() && !newtitle.isEmpty()){
                    String currentTime = new SimpleDateFormat("HH:mm:ss dd/MM/yyyy", Locale.getDefault()).format(new Date());
                    String display = newtitle + "    " + currentTime;
                    titlesList.add(display);
                    noteslist.add(newnotes);
                    titleText.setText("");
                    notesText.setText("");
                    //Save data to SharedPreferences
                    saveNotesToSharePreferemces();
                    Toast.makeText(getApplicationContext(),"Saved notes to the list", Toast.LENGTH_SHORT).show();
                }

            }
            if (mode.equals("edit")){
                if(notePosition != -1 && notePosition < titlesList.size()){
                    String currentTime = new SimpleDateFormat("HH:mm:ss dd/MM/yyyy", Locale.getDefault()).format(new Date());
                    String display = newtitle + "    " + currentTime;
                    titlesList.set(notePosition, display);
                    noteslist.set(notePosition, newnotes);
                    saveNotesToSharePreferemces(); // Lưu trữ dữ liệu sau khi sửa
                }

            }
            Intent intent1 = new Intent(NoteTaking.this, MainActivity.class);
            startActivity(intent1);
            finish();
        });
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(NoteTaking.this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    private void loadNotesFromSharedPreferences() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String savedTitles = prefs.getString(TITLES_NAME,"");
        String savedNotes = prefs.getString(NOTES_KEY,"");
        if (!savedTitles.isEmpty() && !savedNotes.isEmpty()){
            titlesList.addAll(Arrays.asList(savedTitles.split(",")));
            noteslist.addAll(Arrays.asList(savedNotes.split(",")));
        }
    }
    private void saveNotesToSharePreferemces(){
        SharedPreferences.Editor editor= getSharedPreferences(PREFS_NAME,MODE_PRIVATE).edit();
        editor.putString(TITLES_NAME,String.join(",", titlesList));
        editor.putString(NOTES_KEY,String.join(",",noteslist));
        editor.apply();
    }
}