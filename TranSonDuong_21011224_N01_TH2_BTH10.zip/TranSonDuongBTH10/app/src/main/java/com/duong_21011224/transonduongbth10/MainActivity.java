package com.duong_21011224.transonduongbth10;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class MainActivity extends AppCompatActivity {
    private static final String SERVER_IP = "10.4.128.72";
    private static final int SERVER_PORT = 2345;
    private DatagramSocket udpSocket;

    TextView tvax, tvay, tvaz,tvReceive;
    EditText EdSend;
    Button btSend;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvReceive = findViewById(R.id.tvReceive);
        EdSend = findViewById(R.id.EDsend);
        btSend = findViewById(R.id.btSend);
        tvax = findViewById(R.id.tvax);
        tvay = findViewById(R.id.tvay);
        tvaz = findViewById(R.id.tvaz);

        try {
            udpSocket = new DatagramSocket(11093);
        } catch (IOException e) {
            Log.e("UDP", "Socket creation error", e);
            return; // Không tiếp tục nếu socket lỗi
        }

        btSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new Thread(() -> {
                    try {
                        String message = EdSend.getText().toString(); // Gửi nội dung từ EditText
                        byte[] sendData = message.getBytes();
                        InetAddress serverAddress = InetAddress.getByName(SERVER_IP);
                        DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, serverAddress, SERVER_PORT);
                        udpSocket.send(sendPacket);
                    } catch (IOException e) {
                        Log.e("UDP", "ERROR sending data", e);
                    }
                }).start();
            }
        });

        // Thread nhận dữ liệu
        new Thread(() -> {
            byte[] receiveData = new byte[1024];
            DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
            String ax = "", ay = "", az = "";

            while (true) {
                try {

                    udpSocket.receive(receivePacket);
                    String receivedMessage = new String(receivePacket.getData(), 0, receivePacket.getLength());
                    Log.d("UDP", "Received from server: " + receivedMessage);
                    // Chuyển UI update về UI thread
                    runOnUiThread(() -> tvReceive.setText("Received from Server: " + receivedMessage));
                    try {
                        JSONArray jsonArray = new JSONArray(receivedMessage);
                        JSONObject jsonObject = null;
                        for (int i = 0; i < jsonArray.length(); i++) {
                            jsonObject = jsonArray.getJSONObject(i);
                            ax = jsonObject.getString("ax");
                            ay = jsonObject.getString("ay");
                            az = jsonObject.getString("az");

                        }
                        String finalAx = ax;
                        String finalAy = ay;
                        String finalAz = az;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                tvax.setText(finalAx);
                                tvay.setText(finalAy);
                                tvaz.setText(finalAz);
                            }
                        });
                    }catch (JSONException e){
                        Log.e("UDP","Error parsing Json",e);
                    }
                } catch (IOException e) {
                    Log.e("UDP", "Error receiving data", e);
                }
            }
        }).start();
    }
}